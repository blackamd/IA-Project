package db;



import java.sql.*;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
public class connect {
    
    private Connection con;
    private Statement st;
    private ResultSet rs;
    
    public connect(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/house_site","root","");
            st = con.createStatement();
            
        } catch (Exception e) {
            System.out.println("dbconnect .<init>()" + e);
        }
    }
    
    /*Done Successfully */public String sign_up(String name ,String phone ,String address,String email ,String password){
        String quary = "INSERT INTO user (Name,Phone,Address,Email,Password) VALUES('"+name+"','"+ phone+"','"+address+"','"+email+"','"+password+"');";  
        try {
            st.executeUpdate(quary);
        } catch (SQLException ex) {
            System.out.println("SQLException = " + ex);
            
        }
        String retrive_id = "SELECT Id FROM user WHERE Name ='"+ name+"';";
        String user_id = new String();
        try {
            rs = st.executeQuery(retrive_id);
            if(rs.next()){
            user_id = rs.getString("Id");
        }
        } catch (Exception e) {
            System.out.println("Exception = " + e);
        }
        return user_id;
        
    }
    /*Done Successfully */public String log_in(String email) throws SQLException{
        
       String quary = "SELECT Password FROM user WHERE Email ='"+ email+"';";               
       String user_pass = new String();
        
       rs = st.executeQuery(quary);
        if(rs.next()){
            user_pass = rs.getString("Password");
        }              
      
      
      
      return user_pass;
    } 
   /*Done Successfully */ public String[] log_in_with_admin(String email) throws SQLException{
        
       String quary = "SELECT Password, is_admin FROM user WHERE Email ='"+ email+"';";               
       String[] admin = new String[2];
       int ch=0;
        
       rs = st.executeQuery(quary);
        if(rs.next()){
            admin[0] = rs.getString("Password");
            ch = rs.getInt("is_admin");
            admin[1] =Integer.toString(ch);
        }              
      
      
      
      return admin;
    }
   /*Done Successfully */ public String[] get_user_data(String email) throws SQLException{
        
       String quary = "SELECT Id, Name, Phone, Address, Password FROM user WHERE Email ='"+ email+"';";               
           String[] user_data = new String[4];
        
       rs = st.executeQuery(quary);
        if(rs.next()){
            user_data[0] = rs.getString("Id");
            user_data[1] = rs.getString("Name");
            user_data[2] = rs.getString("Phone");
            user_data[3] = rs.getString("Address");
        }              
      
      
      
      return user_data;
    }
   /*Done Successfully */ public ArrayList get_user_ads(String user_id) throws SQLException,NullPointerException{
        int user_id_ = Integer.parseInt(user_id);
       String quary = "SELECT * FROM advertisement WHERE User_Id ="+ user_id_+";";               
           ArrayList single_user_ads = null;
           ArrayList all_user_ads = new ArrayList();
        try{
       rs = st.executeQuery(quary);
        while(rs.next()){
            
            single_user_ads = new ArrayList();
            single_user_ads.add(rs.getString("Id"));
            single_user_ads.add(rs.getString("Date"));
            single_user_ads.add(rs.getString("Type"));
            single_user_ads.add(rs.getString("Size"));
            single_user_ads.add(rs.getString("Price"));
            single_user_ads.add(rs.getString("Location"));
            single_user_ads.add(rs.getString("Floor"));
            single_user_ads.add(rs.getString("Offer"));
            single_user_ads.add(rs.getString("Discription"));
            single_user_ads.add(rs.getString("Status"));
            single_user_ads.add(rs.getString("Suspend"));
            
            all_user_ads.add(single_user_ads);
        }
        
            
        }catch(NullPointerException e){
            System.out.println("e");
        }              
      
      
      
      return all_user_ads;
    }
   /*Done Successfully */ public ArrayList get_ads_details(String ads_id) throws SQLException,NullPointerException{
        int ads_id_ = Integer.parseInt(ads_id);
       String quary = "SELECT Id, Date, Type, Size, Price, Location, Floor, Offer, Discription, Status, User_Id FROM advertisement WHERE Id ="+ ads_id_+";";               
           ArrayList single_user_ads = null;
           ArrayList all_user_ads = new ArrayList();
        try{
       rs = st.executeQuery(quary);
        while(rs.next()){
            
            single_user_ads = new ArrayList();
            single_user_ads.add(rs.getString("Id"));
            single_user_ads.add(rs.getString("Date"));
            single_user_ads.add(rs.getString("Type"));
            single_user_ads.add(rs.getString("Size"));
            single_user_ads.add(rs.getString("Price"));
            single_user_ads.add(rs.getString("Location"));
            single_user_ads.add(rs.getString("Floor"));
            single_user_ads.add(rs.getString("Offer"));
            single_user_ads.add(rs.getString("Discription"));
            single_user_ads.add(rs.getString("Status"));
            single_user_ads.add(rs.getString("User_Id"));
            
            all_user_ads.add(single_user_ads);
        }
        
            
        }catch(NullPointerException e){
            System.out.println("e");
        }              
      
      
      
      return all_user_ads;
    }
   /*Done Successfully */ public ArrayList get_all_ads() throws SQLException,NullPointerException{
       String quary = "SELECT * FROM advertisement ;";               
           ArrayList single_ads = null;
           ArrayList all_users_ads = new ArrayList();
        try{
       rs = st.executeQuery(quary);
        while(rs.next()){
            single_ads = new ArrayList();
            String suspend = rs.getString("Suspend");
            single_ads.add(rs.getString("Id"));
            single_ads.add(rs.getString("Date"));
            single_ads.add(rs.getString("Type"));
            single_ads.add(rs.getString("Size"));
            single_ads.add(rs.getString("Price"));
            single_ads.add(rs.getString("Location"));
            single_ads.add(rs.getString("Floor"));
            single_ads.add(rs.getString("Offer"));
            single_ads.add(rs.getString("Discription"));
            single_ads.add(rs.getString("Status"));
            single_ads.add(rs.getString("Suspend"));
            
            
            all_users_ads.add(single_ads);
            
        }
        
            
        }catch(NullPointerException e){
            System.out.println("e");
        }              
      
      
      
      return all_users_ads;
    }
   /*Done Successfully */ public void add_ads(int user_id, String type ,String size ,String price,String floor ,String location,String offer,String description,String status){
        Date date_in_system = new Date();
        String date = String.valueOf(date_in_system);
        String quary = "INSERT INTO advertisement (User_Id, Date, Type, Size, Price, Location, Floor, Offer, Discription, Status) VALUES("+user_id+",'"+date+"','"+type+"','"+size+"','"+price+"','"+floor+"','"+location+"','"+offer+"','"+description+"','"+status+"');";
        try {
            st.executeUpdate(quary);
        } catch (SQLException ex) {
            System.out.println("SQLException = " + ex);            
        }

    
        
    }
   /*Done Successfully */ public void update_ads(String ads_id, String date, String type ,String size ,String price,String floor ,String location,String offer,String description,String status){
       int ads_id_ = Integer.parseInt(ads_id);
        String quary = "UPDATE advertisement SET Date= '"+date+"', Type='"+type+"', Size='"+size+"', Price='"+price+"', Location='"+location+"', Floor='"+floor+"', Offer='"+offer+"', Discription='"+description+"', Status='"+status+"' WHERE Id ="+ads_id_+";";
        try {
            st.executeUpdate(quary);
        } catch (SQLException ex) {
            System.out.println("SQLException = " + ex);
            
        }
        
        
    }
   /*Done Successfully */ public String[] get_user_data_byID(String id) throws SQLException{
        int user_id = Integer.parseInt(id);
       String quary = "SELECT Name, Phone, Address, Email FROM user WHERE Id ="+ user_id+";";               
           String[] user_data = new String[4];
        
       rs = st.executeQuery(quary);
        if(rs.next()){
            
            user_data[0] = rs.getString("Name");
            user_data[1] = rs.getString("Phone");
            user_data[2] = rs.getString("Address");
            user_data[3] = rs.getString("Email");
        }              
      
      
      
      return user_data;
    } 
   /*Done Successfully */ public void add_admin(String user_name, String user_email){
       String num = "1";
        String quary = "UPDATE user SET is_admin= '"+num+"' WHERE Email ='"+user_email+"';";
        try {
            st.executeUpdate(quary);
        } catch (SQLException ex) {
            System.out.println("SQLException = " + ex);            
        }

    
        
    }
   /*Done Successfully */ public void close_ads(String ads_id){
       int ads_id_ = Integer.parseInt(ads_id);
        String quary = "DELETE FROM advertisement WHERE Id ="+ads_id_+";";
        try {
            st.executeUpdate(quary);
        } catch (SQLException ex) {
            System.out.println("SQLException = " + ex);            
        }

    
        
    }
   /*Done Successfully */ public void suspend_ads(String ads_id){
       int ads_id_ = Integer.parseInt(ads_id);
        String num = "1";
        String quary = "UPDATE advertisement SET Suspend= '"+num+"' WHERE Id ="+ads_id_+";";
        try {
            st.executeUpdate(quary);
        } catch (SQLException ex) {
            System.out.println("SQLException = " + ex);            
        }

    
        
    }
   /*Done Successfully */ public ArrayList show_comments(String ads_id) throws SQLException,NullPointerException{
       String quary = "SELECT * FROM comment WHERE Ads_Id ='"+ ads_id+"';";               
           ArrayList single_ads_com = null;
           ArrayList all_ads_com = new ArrayList();
        try{
       rs = st.executeQuery(quary);
        while(rs.next()){
            
            single_ads_com = new ArrayList();
            single_ads_com.add(rs.getString("Id"));
            single_ads_com.add(rs.getString("User_Id"));
            single_ads_com.add(rs.getString("Text"));
            
            
            all_ads_com.add(single_ads_com);
        }
        
            
        }catch(NullPointerException e){
            System.out.println("e");
        }              
      
      
      
      return all_ads_com;
    }
   public void insert_comment(String user_id , String ads_id ,String comment){
        String quary = "INSERT INTO comment (User_Id, Ads_Id, Text) VALUES('"+user_id+"','"+ ads_id+"','"+comment+"');";  
        try {
            st.executeUpdate(quary);
        } catch (SQLException ex) {
            System.out.println("SQLException = " + ex);
            
        }
        
        
    }
   public void delete(String sessionid){
        String quary = "DELETE FROM user WHERE session_ID ="+sessionid;               
       
        try {
            st.executeUpdate(quary);
        } catch (SQLException ex) {
            System.out.println("dbconnect.setdata()" + ex);
            
        }
        
    }
    
}
